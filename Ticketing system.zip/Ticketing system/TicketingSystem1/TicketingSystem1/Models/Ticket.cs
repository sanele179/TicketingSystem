﻿namespace TicketingSystem1.Models
{
    public class Ticket
    {
        public int ID { get; set; }
        public required string Summary { get; set; }
        public required string Description { get; set; }
    }
}
